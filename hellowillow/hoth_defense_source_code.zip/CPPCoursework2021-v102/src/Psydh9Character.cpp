#include "Psydh9Character.h"
class Psydh9State;


void Psydh9Character::damage() {
	/*for (int x = offsetx; x < animationx; x++) {
		for (int y = offsety; y < animationy; y++) {
			this->state_->getEngine()->getForegroundSurface()->setPixel(x,y,map_->invertPixelColour(x, y, this->state_->getEngine()->getForegroundSurface()));
		}
	}*/
	hitPoints--;
	if (hitPoints == 0) {
		this->state_->getEngine()->context_->TransitionTo(new LoseState(this->state_->getEngine(), this->state_->getEngine()->context_));
	}
	
}

void Psydh9Character::forward() {
	m_iCurrentScreenX -= 5;

	if (this->state_->checkCollision(this)) {
		if (!getEngine()->isKeyPressed(SDLK_j)) {
			this->state_->damagePlayer();
			this->state_->removeObject(this);
		}
	}

	if (m_iCurrentScreenX > 1300 - 69) {
		m_iCurrentScreenX = 1300 - 69;
	}

	if (m_iCurrentScreenX < 50) {
		m_iCurrentScreenX = 50;
		this->state_->removeObject(this);
		this->state_->hit();
	}

	this->virtDraw();
}

void StormTrooper::virtDoUpdate(int iCurrentTime) {
	int random = rand() % 100;
	offsetx = 0;
	offsety = 0;
	animationx = 69;
	animationy = 120;

	//decide how far forward to run before stopping to shoot
	//get lukes coordinates, if in front of him then dont stop and keep running
	if (true) {
		this->forward();
	}
	this->virtDraw();

	if (getEngine()->isKeyPressed(SDLK_k)) {
		if (this->state_->checkCollision(this)) {
			this->state_->drawForeground();
			this->state_->addScore(50);
			this->state_->removeObject(this);
			delete this;
		}
	}

}

void StormTrooper::forward() {
	if (!this->state_->getEngine()->isPaused()) {
		int modulator = 400;

		if (left == true) {
			m_iCurrentScreenX -= 2;
		}
		else {
			m_iCurrentScreenX += 4;
		}

		if (left && this->state_->getDisplayableObject(1)->getXCentre() > this->getX()) {			//AI makes a choice about how frequently to shoot based on the position of the player
			modulator += roundf((this->state_->getDisplayableObject(1)->getXCentre() - this->getX()) / 1300) + 100;
			m_iCurrentScreenX -= 1;
		}

		if (this->state_->getDisplayableObject(1)->getYCentre() == this->getY()) {			//make this more complex for securing marks
			if (rand() % 2 == 1) {
				this->m_iCurrentScreenY += 3;
			}
			else {
				this->m_iCurrentScreenY -= 3;
			}
		} //move up and down to get away from luke

		if (rand() % modulator == 0) {
			this->projectileAttack();
		} //eventually this tends towards zero

		//animate movement
		tick++;
		if (tick == 20) {
			tick = 0;
		}
		offsety = 0;
		offsetx = (roundf(tick / 4) * 93);

		if (m_iCurrentScreenX < 60) {
			m_iCurrentScreenX = 60;
			left = false;
		}

		if (m_iCurrentScreenX > 1500) {
			m_iCurrentScreenX = 1500;
			this->state_->removeObject(this);
		}
	}
}

void StormTrooper::projectileAttack() {
	this->state_->addObject(new Psydh9Projectile(m_iCurrentScreenX, m_iCurrentScreenY + 40, this->m_pEngine, 35, 15, true, this->state_));

}

void Psydh9Projectile::move() {
	m_iCurrentScreenX -= 10;

	if (this->state_->checkCollision(this)) {
		if (!getEngine()->isKeyPressed(SDLK_j)) {
			this->state_->damagePlayer();
			this->state_->removeObject(this);
			delete this;
		}
	}

	if (m_iCurrentScreenX > 1300 - 69) {
		m_iCurrentScreenX = 1300 - 69;
	}

	if (m_iCurrentScreenX < 50) {
		m_iCurrentScreenX = 50;
		this->state_->removeObject(this);
		this->state_->hit();
		delete this;
	}

	this->virtDraw(); //not uninitialised, see line 139
}

void Psydh9Projectile::virtDoUpdate(int iCurrentTime) {
	if (!this->state_->getEngine()->isPaused()) {
		this->move();
		this->virtDraw();

		if (getEngine()->isKeyPressed(SDLK_j)) {
			if (this->state_->checkCollision(this)) {
				this->state_->addScore(20);
				this->state_->removeObject(this);
			}
		}
	}
}

void Luke::virtDoUpdate(int iCurrentTime) {
	offsetx = 0;
	offsety = 0;
	animationx = 69;
	animationy = 120;
	if (!this->state_->getEngine()->isPaused()) {
		//check there are no animations playing then allow for movement
		if (jumpedTicks >= 0) {
			offsetx = 70;
			if (jumpedTicks < 45) {
				m_iCurrentScreenY += 3;

			}
			else if (jumpedTicks > 45) {
				m_iCurrentScreenY -= 3;
			}
			jumpedTicks--;

		}
		else if (lightTicks >= 0) { //J
			animationx = 134;
			animationy = 130;
			offsety = 300;

			int a = roundf((15 - lightTicks) / 3);

			offsetx = a * 136;

			lightTicks--;

			//check for collision?
		}
		else if (heavyTicks >= 0) { //K
			animationx = 134;
			animationy = 130;
			offsety = 462;

			offsetx = roundf((16 - heavyTicks) / 4) * 136;

			heavyTicks--;

		}
		else {

			if (getEngine()->isKeyPressed(SDLK_w)) {
				m_iCurrentScreenY -= 1;

				//animate movement
				tick++;
				if (tick == 28) {
					tick = 0;
				}
				offsety = 160;
				offsetx = (roundf(tick / 4) * 93);

				if (m_iCurrentScreenY < 660) {
					m_iCurrentScreenY = 660;
				}

				if (m_iCurrentScreenY < 0) {
					m_iCurrentScreenY = 0;
				}
			}
			else if (getEngine()->isKeyPressed(SDLK_s)) {
				m_iCurrentScreenY += 1;

				//animate movement
				tick++;
				if (tick == 28) {
					tick = 0;
				}
				offsety = 160;
				offsetx = (roundf(tick / 4) * 93);

				if (m_iCurrentScreenY > 800 - 110) {
					m_iCurrentScreenY = 800 - 110;
				}

				if (m_iCurrentScreenY < 0) {
					m_iCurrentScreenY = 0;
				}
			}
			else if (getEngine()->isKeyPressed(SDLK_a)) {
				m_iCurrentScreenX -= 3;

				//animate movement
				tick++;
				if (tick == 28) {
					tick = 0;
				}
				offsety = 160;
				offsetx = (roundf(tick / 4) * 93);

				if (m_iCurrentScreenX > 1300 - 69) {
					m_iCurrentScreenX = 1300 - 69;
				}

				if (m_iCurrentScreenX < 0) {
					m_iCurrentScreenX = 0;
				}
			}
			else if (getEngine()->isKeyPressed(SDLK_d)) {
				m_iCurrentScreenX += 3;

				//animate movement
				tick++;
				if (tick == 28) {
					tick = 0;
				}
				offsety = 160;
				offsetx = (roundf(tick / 4) * 93);

				if (m_iCurrentScreenX > 1300 - 69) {
					m_iCurrentScreenX = 1300 - 69;
				}

			}
			else if (getEngine()->isKeyPressed(SDLK_SPACE)) {
				jumpedTicks = 90;
			}
			else if (getEngine()->isKeyPressed(SDLK_j)) {
				lightTicks = 18;
			}
			else if (getEngine()->isKeyPressed(SDLK_k)) {
				heavyTicks = 20;
			}
			else {
				tick = 0;
			}
		}
	}
	getEngine()->redrawDisplay();
};