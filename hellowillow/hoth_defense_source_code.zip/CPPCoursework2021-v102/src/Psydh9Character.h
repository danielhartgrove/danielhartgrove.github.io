#pragma once
#include "header.h"
#include "BaseEngine.h"
#include "Psydh9ImagePixelMapping.h"
#include "DisplayableObject.h"
#include "Psydh9State.h"
#include <iostream>
# ifdef _WIN32
#include <Windows.h>
#pragma comment(lib, "Winmm.lib")
# endif

class Psydh9State;

class Psydh9Character :
    public DisplayableObject
{
public:
	Psydh9Character(int xStart, int yStart, BaseEngine* engine, int iWidth, int iHeight, bool useTopLeftFor00, Psydh9State* state) : DisplayableObject(xStart, yStart, engine, iWidth, iHeight, useTopLeftFor00) {
		sprite = ImageManager::loadImage("luke_sprites.png", true);
		this->state_ = state;
	};
	virtual void forward();
	virtual void lightAttack() {};
	virtual void heavyAttack() {};
	virtual void projectileAttack() {};
	virtual void jump() {}; 
	virtual int getX() { return this->getXCentre(); }
	virtual int getY() { return this->getYCentre(); }

	virtual void virtDraw(){
		getEngine()->lockForegroundForDrawing();
		sprite.renderImage(getEngine()->getForegroundSurface(), 0, 0, 500, 375, 100, 100);
		getEngine()->unlockForegroundForDrawing();
	};

	virtual void virtDoUpdate(int iCurrentTime) {
		virtDraw();
	};

	virtual void damage();

	virtual int getHP() {
		return hitPoints;
	};
	SimpleImage sprite;

protected:
	
	Psydh9State* state_ = nullptr;
	int hitPoints = 0;
	int offsetx = 0;
	int offsety = 0;
	int tick = 0;	//frames for running
	int jumpedTicks = 0; //animation frames
	int heavyTicks = 0; //animation frames
	int lightTicks = 0; //animation frames
	int animationx = 69;
	int animationy = 120;
};

class StormTrooper : public Psydh9Character {
public:
	StormTrooper(int xStart, int yStart, BaseEngine* engine, int iWidth, int iHeight, bool useTopLeftFor00, Psydh9State* state) : Psydh9Character(xStart, yStart, engine, iWidth, iHeight, useTopLeftFor00, state) {
		sprite = ImageManager::loadImage("trooper_sprites.png", true);
		sprite.setTransparencyColour(0xff00ff);
		this->m_iCurrentScreenX = xStart;
		this->m_iCurrentScreenY = yStart;
		this->animationx = iWidth;
		this->animationy = iHeight;
		this->state_ = state;
	};

	void virtDraw() override {
		getEngine()->lockForegroundForDrawing();
		sprite.renderImageWithMaskAndTransparency(getEngine()->getForegroundSurface(), 12 + offsetx, 194 + offsety, this->m_iCurrentScreenX, this->m_iCurrentScreenY, animationx, animationy, 0xff00ff, 100);
		getEngine()->unlockForegroundForDrawing();
	};

	void virtDoUpdate(int iCurrentTime) override;

	void forward() override;

	void projectileAttack() override;

protected:
	int animationx = 90;
	int animationy = 164;
	bool left = true;
};

class Luke : public Psydh9Character
{
public:
	Luke(int xStart, int yStart, BaseEngine* engine, int iWidth, int iHeight, bool useTopLeftFor00, Psydh9State* state) : Psydh9Character(xStart, yStart, engine, iWidth, iHeight, useTopLeftFor00, state) {
		sprite = ImageManager::loadImage("luke_sprites.png", true);
		sprite.setTransparencyColour(0xff00ff);
		this->m_iCurrentScreenX = xStart;
		this->m_iCurrentScreenY = yStart;
		this->animationx = iWidth;
		this->animationy = iHeight;
		this->state_ = state;
# ifdef _WIN32
		PlaySound("not_afraid.wav", GetModuleHandle(NULL), SND_FILENAME | SND_ASYNC);
# endif
	};


	void virtDraw() override {
		getEngine()->lockForegroundForDrawing();
		sprite.renderImageWithMaskAndTransparency(getEngine()->getForegroundSurface(), 12 + offsetx, 202 + offsety, this->m_iCurrentScreenX, this->m_iCurrentScreenY, animationx, animationy, 0xff00ff, 100);
		getEngine()->unlockForegroundForDrawing();
	};

	void virtDoUpdate(int iCurrentTime) override;

protected:
	int hitPoints = 10;
	int animationx = 69;
	int animationy = 120;
};

class Psydh9Projectile :
	public DisplayableObject
{
public:
	SimpleImage sprite;

	Psydh9Projectile(int xStart, int yStart, BaseEngine* engine, int iWidth, int iHeight, bool useTopLeftFor00, Psydh9State* state) : DisplayableObject(xStart, yStart, engine, iWidth, iHeight, useTopLeftFor00) {
		# ifdef _WIN32
			PlaySound("blaster.wav", GetModuleHandle(NULL), SND_FILENAME | SND_ASYNC);
		# endif
		sprite = ImageManager::loadImage("trooper_sprites.png", true);
		sprite.setTransparencyColour(0xff00ff);
		this->m_iCurrentScreenX = xStart;
		this->m_iCurrentScreenY = yStart;
		this->state_ = state;
	};

	void virtDraw() override{
		getEngine()->lockForegroundForDrawing();
		sprite.renderImageWithMaskAndTransparency(getEngine()->getForegroundSurface(), 0, 0, this->m_iCurrentScreenX, this->m_iCurrentScreenY, 35, 15, 0xff00ff, 100);
		getEngine()->unlockForegroundForDrawing();
	}

	void virtDoUpdate(int iCurrentTime) override;

	void move();

protected:
	Psydh9State* state_;

};