#pragma once
#include "header.h"
#include "Psydh9Character.h"
#include "UtilCollisionDetection.h"

class Psydh9Collision :
    public CollisionDetection
{

    static bool checkRectanglesWithMask(Psydh9Character* obj1, Psydh9Character* obj2) {
        int x = 0;
        int y = 0;

        for (x = obj1->getDrawingRegionLeft(); x < obj1->getDrawingRegionRight(); x++) {
            for (y = obj2->getDrawingRegionLeft(); y < obj2->getDrawingRegionRight(); y++) {
                if(obj2->sprite.getPixelColour(x,y) != 0xFF00FF);
            }
        }
    }
};

