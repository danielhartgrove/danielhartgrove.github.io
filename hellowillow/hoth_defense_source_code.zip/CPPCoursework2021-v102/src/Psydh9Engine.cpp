#include "Psydh9Engine.h"

class Psydh9Context;

Psydh9Engine::Psydh9Engine() {
    this->context_ = new Psydh9Context(this);
    SDL_SetWindowTitle(this->m_pSDL2Window, "STAR WARS: HOTH DEFENSE");
};

Psydh9Engine::~Psydh9Engine() {
    delete this->context_;
};

void Psydh9Engine::virtSetupBackgroundBuffer() {
    this->context_->setupBackgroundBuffer();
};

int Psydh9Engine::virtInitialiseObjects() {
    this->context_->initialiseObjects();
    return 0;
};

void Psydh9Engine::virtKeyDown(int keyCode) {
    this->context_->keyDown(keyCode);
};


void Psydh9Engine::virtMouseDown(int button, int x, int y) {
    this->context_->mouseDown(button, x, y);
};

void Psydh9Engine::virtMainLoopDoAfterUpdate() {
    if(!this->isPaused())
        this->context_->doUpdate();
};

void Psydh9Engine::setBackgroundSurface(DrawingSurface* newSurface) {
    this->m_pBackgroundSurface->mySDLLockSurface();
    this->copySurface(newSurface, m_pBackgroundSurface);
    this->m_pBackgroundSurface->mySDLUnlockSurface();
}

void Psydh9Engine::virtDrawStringsUnderneath() {
    this->context_->drawBackgroundString();
}

void Psydh9Engine::virtMouseWheel(int x, int y, int which, int timestamp) {
    this->context_->mouseWheel(x, y, which, timestamp);
}

void Psydh9Engine::copyAllBackgroundBuffer(int offset)
{
    m_pForegroundSurface->copyRectangleFrom(m_pBackgroundSurface, 0, 0, getWindowWidth(), getWindowHeight(), offset, 0);
}
