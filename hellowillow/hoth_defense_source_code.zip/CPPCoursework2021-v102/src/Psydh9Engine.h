#pragma once
#include "header.h"
#include "Psydh9State.h"
#include "TileManager.h"

class Psydh9Context;

class Psydh9Engine :
    public BaseEngine
{
public:
    Psydh9Context* context_ = nullptr;

    Psydh9Engine();

    ~Psydh9Engine();

    void virtSetupBackgroundBuffer();

    int virtInitialiseObjects();

    void virtKeyDown(int keyCode);

    void virtMouseDown(int button, int x, int y);

    void virtMainLoopDoAfterUpdate();

    void virtDrawStringsUnderneath();

    void setBackgroundSurface(DrawingSurface* newSurface);

    void virtMouseWheel(int x, int y, int which, int timestamp);

    void copyAllBackgroundBuffer(int offset);

};

