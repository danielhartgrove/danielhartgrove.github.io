#include "Psydh9ImagePixelMapping.h"

bool Psydh9ImagePixelMapping::invertPixelColour(int x, int y, DrawingSurface* image) {

	int color = image->rawGetPixel(x,y);
	int invertedcolor = color;
	if (!(m_iTransparencyColour == color)) {
		invertedcolor = 0xFFFFFF - color;
		if (invertedcolor == m_iTransparencyColour) {
			invertedcolor += 100;
		}
		return true;
	}

	return false;

}

void Psydh9ImagePixelMapping::setTransparencyColour(int colour)
{
	m_iTransparencyColour = colour;
}