#pragma once
#include "header.h"
#include "BaseEngine.h"
#include "SimpleImage.h"
#include "ImagePixelMapping.h"

class Psydh9ImagePixelMapping :
    public ImagePixelMapping
{
public:
    Psydh9ImagePixelMapping() {};

    Psydh9ImagePixelMapping(BaseEngine* engine) {
        this->engine_ = engine;
    };

    Psydh9ImagePixelMapping(BaseEngine* engine, int iColour) {
        this->engine_ = engine;
        this->setTransparencyColour(iColour);
    };

    bool invertPixelColour(int x, int y, DrawingSurface* image);
    bool mapCoordinates(double& x, double& y, const SimpleImage& image) override { return true; }
    void setTransparencyColour(int iColour);

    // this is worth 2 whole marks please get it working dan

private:
    int m_iTransparencyColour;
    BaseEngine* engine_ = nullptr;
};

