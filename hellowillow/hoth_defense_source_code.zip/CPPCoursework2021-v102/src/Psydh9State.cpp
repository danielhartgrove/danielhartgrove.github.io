#include "Psydh9State.h"

class Psydh9Character;
class StormTrooper;
class Psydh9Projectile;
class Psydh9Engine;

Psydh9State::Psydh9State() {  };

Psydh9State::Psydh9State(Psydh9Engine* engine, Psydh9Context* context) {
	this->engine_ = engine;
	this->context_ = context;
};

Psydh9State::~Psydh9State() {};

int Psydh9State::initialiseObjects() {
	this->engine_->drawableObjectsChanged();
	this->engine_->destroyOldObjects(true);
	return 0;
}

void Psydh9State::addObject(DisplayableObject* object)
{
	this->engine_->appendObjectToArray(object);
	this->engine_->drawableObjectsChanged();
}

void Psydh9State::removeObject(DisplayableObject* object)
{
	this->engine_->removeDisplayableObject(object);
	this->engine_->drawableObjectsChanged();
};

Psydh9Engine* Psydh9State::getEngine() { return this->engine_; }

MainMenuState::MainMenuState(Psydh9Engine* engine, Psydh9Context* context) {
	this->engine_ = engine;
	this->context_ = context;
	this->m_filterScaling = new Psydh9FilterPointsScaling(0, 0, this->engine_);
	this->m_filterTranslation = new Psydh9FilterPointsTranslation(0, 0, this->m_filterScaling);
	this->engine_->getBackgroundSurface()->setDrawPointsFilter(m_filterTranslation);
	this->engine_->getForegroundSurface()->setDrawPointsFilter(m_filterTranslation);
	this->engine_->redrawDisplay();
};

MainMenuState::	~MainMenuState() {
	delete this->m_filterScaling;
	delete this->m_filterTranslation;
	this->engine_->drawableObjectsChanged();
	this->engine_->destroyOldObjects(true);
}

void MainMenuState::setupBackgroundBuffer() {
	SimpleImage sprite = ImageManager::loadImage("gameLogo.png", true);
	int windowWidth = this->engine_->getWindowWidth();
	int windowHeight = this->engine_->getWindowHeight();

	this->engine_->lockBackgroundForDrawing();
	this->engine_->fillBackground(0x000000);

	for (int iX = 0; iX < windowWidth; iX++)
		for (int iY = 0; iY < windowHeight; iY++)
			switch (rand() % 100)
			{
			case 0: this->engine_->setBackgroundPixel(iX, iY, 0xFFFFFF); break;
			}

	sprite.renderImageWithMaskAndTransparency(this->engine_->getBackgroundSurface(), 0, 0, 416, 200, 468, 136, 0, 100);
	this->engine_->drawBackgroundString(335, 600, "Click anywhere to start, Press escape to close", 0xFFE81F, NULL);

	this->engine_->redrawDisplay();
	this->engine_->unlockBackgroundForDrawing();

};

void MainMenuState::keyDown(int keyCode) {
	int windowWidth = this->engine_->getWindowWidth();
	int windowHeight = this->engine_->getWindowHeight();

	if (keyCode == 27) {
		exit(1);
	}

};

void MainMenuState::mouseWheel(int x, int y, int which, int timestamp)
{
	// We grab the position of the centre of the screen before the zoom
	int iOldCentreX = this->engine_->convertClickedToVirtualPixelXPosition(this->engine_->getWindowWidth() / 2);
	int iOldCentreY = this->engine_->convertClickedToVirtualPixelYPosition(this->engine_->getWindowHeight() / 2);

	if (y < 0)
		this->m_filterScaling->compress();
	else if (y > 0)
		this->m_filterScaling->stretch();

	// Now we grab the position after the zoom
	int iNewCentreX = this->engine_->convertClickedToVirtualPixelXPosition(this->engine_->getWindowWidth() / 2);
	int iNewCentreY = this->engine_->convertClickedToVirtualPixelYPosition(this->engine_->getWindowHeight() / 2);

	// Apply a translation to offset so it appears to have zoomed on the centre by moving the old centre back to the centre of the screen
	this->m_filterTranslation->changeOffset(iNewCentreX - iOldCentreX, iNewCentreY - iOldCentreY);
	// Uncomment the above line to zoom in on centre rather than top left

	// Redraw the background
	this->setupBackgroundBuffer(); // Force total redraw
}

void MainMenuState::mouseDown(int button, int x, int y) {
	if (button == SDL_BUTTON_LEFT) {
		this->context_->TransitionTo(new NameEnterState(engine_, context_));
	}
}

NameEnterState::NameEnterState(Psydh9Engine* engine, Psydh9Context* context) {
	this->engine_ = engine;
	this->context_ = context;
	this->engine_->redrawDisplay();
};

NameEnterState::~NameEnterState() {
	this->engine_->drawableObjectsChanged();
	this->engine_->destroyOldObjects(true);
}

void NameEnterState::drawBackground() {

	int windowWidth = this->engine_->getWindowWidth();
	int windowHeight = this->engine_->getWindowHeight();

	this->engine_->lockBackgroundForDrawing();

	this->engine_->fillBackground(0x000000);

	this->engine_->drawBackgroundString(375, 200, "Enter your name (followed by Enter)", 0xFFE81F, NULL);

	this->drawBackgroundString();

	this->engine_->redrawDisplay();

	this->engine_->unlockBackgroundForDrawing();
};

void NameEnterState::drawBackgroundString() {
	this->engine_->lockBackgroundForDrawing();
	this->engine_->drawBackgroundString(625, 400, this->buffer, 0xFFE81F, NULL);
	this->engine_->unlockBackgroundForDrawing();
}

void NameEnterState::keyDown(int keyCode) {
	int windowWidth = this->engine_->getWindowWidth();
	int windowHeight = this->engine_->getWindowHeight();

	if (charsentered < 3) {

		if (keyCode == SDLK_a) {
			buffer[charsentered] = 'a'; charsentered++;
		}
		else if (keyCode == SDLK_b) {
			buffer[charsentered] = 'b'; charsentered++;
		}
		else if (keyCode == SDLK_c) {
			buffer[charsentered] = 'c'; charsentered++;
		}
		else if (keyCode == SDLK_d) {
			buffer[charsentered] = 'd'; charsentered++;
		}
		else if (keyCode == SDLK_e) {
			buffer[charsentered] = 'e'; charsentered++;
		}
		else if (keyCode == SDLK_f) {
			buffer[charsentered] = 'f'; charsentered++;
		}
		else if (keyCode == SDLK_g) {
			buffer[charsentered] = 'g'; charsentered++;
		}
		else if (keyCode == SDLK_h) {
			buffer[charsentered] = 'h'; charsentered++;
		}
		else if (keyCode == SDLK_i) {
			buffer[charsentered] = 'i'; charsentered++;
		}
		else if (keyCode == SDLK_j) {
			buffer[charsentered] = 'j'; charsentered++;
		}
		else if (keyCode == SDLK_k) {
			buffer[charsentered] = 'k'; charsentered++;
		}
		else if (keyCode == SDLK_l) {
			buffer[charsentered] = 'l'; charsentered++;
		}
		else if (keyCode == SDLK_m) {
			buffer[charsentered] = 'm'; charsentered++;
		}
		else if (keyCode == SDLK_n) {
			buffer[charsentered] = 'n'; charsentered++;
		}
		else if (keyCode == SDLK_o) {
			buffer[charsentered] = 'o'; charsentered++;
		}
		else if (keyCode == SDLK_p) {
			buffer[charsentered] = 'p'; charsentered++;
		}
		else if (keyCode == SDLK_q) {
			buffer[charsentered] = 'q'; charsentered++;
		}
		else if (keyCode == SDLK_r) {
			buffer[charsentered] = 'r'; charsentered++;
		}
		else if (keyCode == SDLK_s) {
			buffer[charsentered] = 's'; charsentered++;
		}
		else if (keyCode == SDLK_t) {
			buffer[charsentered] = 't'; charsentered++;
		}
		else if (keyCode == SDLK_u) {
			buffer[charsentered] = 'u'; charsentered++;
		}
		else if (keyCode == SDLK_v) {
			buffer[charsentered] = 'v'; charsentered++;
		}
		else if (keyCode == SDLK_w) {
			buffer[charsentered] = 'w'; charsentered++;
		}
		else if (keyCode == SDLK_x) {
			buffer[charsentered] = 'x'; charsentered++;
		}
		else if (keyCode == SDLK_y) {
			buffer[charsentered] = 'y'; charsentered++;
		}
		else if (keyCode == SDLK_z) {
			buffer[charsentered] = 'z'; charsentered++;
		}
		else if(keyCode == SDLK_BACKSPACE) {
			charsentered--;
			buffer[charsentered] = '_';
		}
	}
	else {
		if (keyCode == 13) {
			//write to file
			std::ofstream myfile;
			myfile.open("scores.txt", std::ios_base::app); //opens the file in append mode
			myfile << "{";
			myfile << this->buffer;
			myfile << ";";
			myfile.close();
			this->context_->TransitionTo(new BattleState(engine_, context_));
		}
		else if (keyCode == SDLK_BACKSPACE) {
			charsentered--;
			buffer[charsentered] = '_';
		}
	};

};

void NameEnterState::doUpdate() {
	this->drawBackground();
}

WinState::WinState(Psydh9Engine* engine, Psydh9Context* context) {
	this->engine_ = engine;
	this->context_ = context;

	for (int i = 0; i < 5; i++) {
		surfaces[i] = new DrawingSurface(this->engine_);
		surfaces[i]->createSurface(1300, 800);
		surfaces[i]->mySDLLockSurface();
	}

	winImage = ImageManager::loadImage("winImg.png", false);
	winBack1 = ImageManager::loadImage("winBack1.png", false);
	winBack2 = ImageManager::loadImage("winBack2.png", false);
	winBack3 = ImageManager::loadImage("winBack3.png", false);
	winBack4 = ImageManager::loadImage("winBack4.png", false);
	winBack5 = ImageManager::loadImage("Back5.png", false);

	winImage = ImageManager::loadImage("winImg.png", false);
	winBack1.renderImage(this->surfaces[0], 0, 0, 0, 0, winBack1.getWidth(), winBack1.getHeight());
	winBack2.renderImage(this->surfaces[1], 0, 0, 0, 0, winBack2.getWidth(), winBack2.getHeight());
	winBack3.renderImage(this->surfaces[2], 0, 0, 0, 0, winBack3.getWidth(), winBack3.getHeight());
	winBack4.renderImage(this->surfaces[3], 0, 0, 0, 0, winBack4.getWidth(), winBack4.getHeight());
	winBack5.renderImage(this->surfaces[4], 0, 0, 0, 0, winBack5.getWidth(), winBack5.getHeight());

	for (int i = 0; i < 5; i++) {

		winImage.renderImageWithMaskAndTransparency(this->surfaces[i], 0, 0, 0, 0, winImage.getWidth(), winImage.getHeight(), 0xff00ff, 100);

		surfaces[i]->mySDLUnlockSurface();
	}

	this->engine_->redrawDisplay();
};

void WinState::drawBackground() {
	int windowWidth = this->engine_->getWindowWidth();
	int windowHeight = this->engine_->getWindowHeight();

	this->engine_->lockBackgroundForDrawing();

	//change the background surface.

	this->engine_->setBackgroundSurface(surfaces[(int)roundf(frame / 6)]);

	frame++;
	if (frame == 30) {
		frame = 0;
	}

	this->engine_->drawBackgroundString(10, 700, "Press enter to view high scores select", 0xFFE81F, NULL);
	this->engine_->unlockBackgroundForDrawing();
	this->engine_->redrawDisplay();
};

void WinState::keyDown(int keyCode) {

	if (keyCode == 13) {
		this->context_->TransitionTo(new ScoreState(engine_, context_));
	}
	else if (keyCode == 27) {
		exit(1);
	}
};

void WinState::doUpdate() {
	this->drawBackground();
}

LoseState::LoseState(Psydh9Engine* engine, Psydh9Context* context) {
	this->engine_ = engine;
	this->context_ = context;

	for (int i = 0; i < 5; i++) {
		surfaces[i] = new DrawingSurface(this->engine_);
		surfaces[i]->createSurface(1300, 800);
		surfaces[i]->mySDLLockSurface();
	}

	loseImage = ImageManager::loadImage("loseImg.png", false);
	loseBack1 = ImageManager::loadImage("loseBack1.png", false);
	loseBack2 = ImageManager::loadImage("loseBack2.png", false);
	loseBack3 = ImageManager::loadImage("loseBack3.png", false);
	loseBack4 = ImageManager::loadImage("loseBack4.png", false);
	loseBack5 = ImageManager::loadImage("Back5.png", false);

	loseImage = ImageManager::loadImage("loseImg.png", false);
	loseBack1.renderImage(this->surfaces[0], 0, 0, 0, 0, loseBack1.getWidth(), loseBack1.getHeight());
	loseBack2.renderImage(this->surfaces[1], 0, 0, 0, 0, loseBack2.getWidth(), loseBack2.getHeight());
	loseBack3.renderImage(this->surfaces[2], 0, 0, 0, 0, loseBack3.getWidth(), loseBack3.getHeight());
	loseBack4.renderImage(this->surfaces[3], 0, 0, 0, 0, loseBack4.getWidth(), loseBack4.getHeight());
	loseBack5.renderImage(this->surfaces[4], 0, 0, 0, 0, loseBack5.getWidth(), loseBack5.getHeight());

	for (int i = 0; i < 5; i++) {
		
		loseImage.renderImageWithMaskAndTransparency(this->surfaces[i], 0, 0, 0, 0, loseImage.getWidth(), loseImage.getHeight(), 0xff00ff, 100);

		surfaces[i]->mySDLUnlockSurface();
	}

	this->engine_->redrawDisplay();
};

LoseState::~LoseState() {
	for (int i = 0; i < 5; i++) {
		delete surfaces[i];
	}
	free(surfaces);
}

void LoseState::drawBackground() {
	int windowWidth = this->engine_->getWindowWidth();
	int windowHeight = this->engine_->getWindowHeight();

	this->engine_->lockBackgroundForDrawing();

	//change the background surface.

	this->engine_->setBackgroundSurface(surfaces[(int)roundf(frame / 6)]);

	frame++;
	if (frame == 30) {
		frame = 0;
	}

	this->engine_->drawBackgroundString(10, 700, "Press enter to view high scores select", 0xFFE81F, NULL);
	this->engine_->unlockBackgroundForDrawing();
	this->engine_->redrawDisplay();
	
};

void LoseState::keyDown(int keyCode) {

	if (keyCode == 13) {
		this->context_->TransitionTo(new ScoreState(engine_, context_));
	}
	else if (keyCode == 27) {
		exit(1);
	}
};

void LoseState::doUpdate() {
	drawBackground();
}

ScoreState::ScoreState(Psydh9Engine* engine, Psydh9Context* context) {
	this->engine_ = engine;
	this->context_ = context;
	this->engine_->redrawDisplay();
};

ScoreState::~ScoreState() {
}

void ScoreState::drawBackground() {

	char input[32];
	char output[32];
	

	int windowWidth = this->engine_->getWindowWidth();
	int windowHeight = this->engine_->getWindowHeight();

	this->engine_->lockBackgroundForDrawing();

	this->engine_->fillBackground(0x000000);

	for (int iX = 0; iX < windowWidth; iX++)
		for (int iY = 0; iY < windowHeight; iY++)
			switch (rand() % 100)
			{
			case 0: this->engine_->setBackgroundPixel(iX, iY, 0xFFFFFF); break;
			}

	this->engine_->drawBackgroundString(350, 200, "High Scores", 0xFFE81F, NULL);

	std::ifstream myfile;
	myfile.open("scores.txt", std::ios_base::in); //opens the file in read mode
	int i = 0;
	while (!myfile.eof()) {
		myfile.getline(input, 32);
		std::strncpy(output, input + 1, 3);
		output[3] = ' '; // add space character
		std::strncpy(output + 4, input + 5, sizeof(input) - 7);
		output[sizeof(output) - 2] = '\0';

		for (int j = 0; j < 32; j++) {
			if (output[j] == '}') {
				output[j] = ' ';
			}
		}
	
		this->engine_->drawBackgroundString(350, 240 + (20 * i++), output, 0xFFE81F, NULL);

		if (i == 5) {
			break;
		}
	}

	myfile.close();

	this->engine_->drawBackgroundString(300, 700, "Press enter to play again or escape to exit", 0xFFE81F, NULL);

	this->engine_->unlockBackgroundForDrawing();
};

void ScoreState::keyDown(int keyCode) {

	if (keyCode == 13) {
		this->context_->TransitionTo(new NameEnterState(engine_, context_));
	}
	else if (keyCode == 27) {
		exit(1);
	}
};

BattleState::BattleState(Psydh9Engine* engine, Psydh9Context* context) {
	this->engine_ = engine;
	this->context_ = context;
	this->startTime = time(NULL);
	this->tileManager_ = new Psydh9TileManager(20, 20, hitPoints, 1);
	this->tileManager_->setTopLeftPositionOnScreen(0, 20);
	this->imageMapper = new Psydh9ImagePixelMapping(this->engine_, 0xFF00FF);
	hoth = ImageManager::loadImage("hoth.png", true);
	hothfloor = ImageManager::loadImage("hoth_floor.png", true);
	srand(time(0));
	this->engine_->redrawDisplay();
};

BattleState::~BattleState() {
	this->engine_->destroyOldObjects(true);
	delete(this->tileManager_);
	this->engine_->redrawDisplay();
}

void BattleState::setupBackgroundBuffer() {
	int windowWidth = this->engine_->getWindowWidth();
	int windowHeight = this->engine_->getWindowHeight();

	this->engine_->lockBackgroundForDrawing();

	hoth.renderImage(this->engine_->getBackgroundSurface(), shift+100, 150, 0, 0, windowWidth, windowHeight);
	hothfloor.renderImageWithMaskAndTransparency(this->engine_->getBackgroundSurface(), 0, 0, 0, 0, windowWidth, windowHeight, 0xff00ff, 100);

	this->engine_->unlockBackgroundForDrawing();
}

void BattleState::drawBackground() {
	int windowWidth = this->engine_->getWindowWidth();
	int windowHeight = this->engine_->getWindowHeight();

	this->engine_->lockBackgroundForDrawing();

	this->engine_->copyAllBackgroundBuffer(shift);
	hoth.renderImage(this->engine_->getBackgroundSurface(), shift+100, 150, 0, 0, windowWidth, windowHeight);
	hothfloor.renderImageWithMaskAndTransparency(this->engine_->getBackgroundSurface(), 0, 0, 0, 0, windowWidth, windowHeight, 0xff00ff, 100);

	this->engine_->drawBackgroundString(20, 10, "Defend the Shield Generator!", 0xFFE81F, NULL);
	this->engine_->drawBackgroundString(1000, 10, "Level: ", 0xFFE81F, NULL);
	this->engine_->drawBackgroundString(1100, 10, std::to_string(level).c_str() , 0xFFE81F, NULL);
	this->engine_->drawBackgroundString(1000, 30, "Score: ", 0xFFE81F, NULL);
	this->engine_->drawBackgroundString(1100, 30, std::to_string(score).c_str(), 0xFFE81F, NULL);

	if (this->engine_->isPaused()) {
		this->engine_->drawBackgroundString(375, 400, "Paused", 0xFFE81F, NULL);
	}

	this->engine_->redrawDisplay();
	this->engine_->unlockBackgroundForDrawing();
};

void BattleState::doUpdate() {

	this->drawBackground();

	this->engine_->lockBackgroundForDrawing();
	for (int i = 0; i < hitPoints; i++) {
		this->tileManager_->virtDrawTileAt(this->engine_, this->engine_->getBackgroundSurface(), 10, 0, i*20, 20);
	}
	this->engine_->unlockBackgroundForDrawing();

	if(framesSinceSpawn > requiredFrames) {
		addStormTrooper();
		framesSinceSpawn = 0;
	}
	else {
		framesSinceSpawn++;
	}

	if (hitPoints == 0) {
		this->context_->TransitionTo(new LoseState(engine_, context_));
	}
}

void BattleState::keyDown(int keyCode) {

	// the drawing of the background must use this->engine->copyAllBackgroundBuffer()
	int windowWidth = this->engine_->getWindowWidth();
	int windowHeight = this->engine_->getWindowHeight();

	switch (keyCode) {
	case SDLK_TAB:
		if (this->engine_->isPaused()) {
			this->engine_->unpause();
		}
		else {
			this->engine_->pause();
			this->engine_->drawBackgroundString(625, 400, "Paused", 0xFFE81F, NULL);
			this->engine_->redrawDisplay();
		}
		break;
	case SDLK_a:
		if(shift > -50)
			shift -= 2;
		break;
	case SDLK_d:
		if (shift < 50)
			shift += 2;
		break;
	}

};

int BattleState::initialiseObjects() {
	// Record the fact that we are about to change the array - so it doesn't get used elsewhere without reloading it
	this->engine_->drawableObjectsChanged();

	// Destroy any existing objects
	this->engine_->destroyOldObjects(true);

	this->engine_->createObjectArray(2);

	this->engine_->storeObjectInArray(1, new Luke(100, 670, this->engine_, 69, 118 , true, this));

	this->engine_->storeObjectInArray(0, new ShieldGenerator(700, 670, this->engine_, 69, 118, true));

	this->engine_->setAllObjectsVisible(true);

	return 0;
};

void BattleState::addStormTrooper() {
	this->addObject(new StormTrooper(1400, rand() % 30 + 655, this->engine_, 69, 118, true, this)); //spawns offscreen so that it can still shoot and deter players from spam
}

void BattleState::removeObject(DisplayableObject* object) {
	this->engine_->removeDisplayableObject(object);
}

void BattleState::hit() {
	hitPoints--;
	if (hitPoints == 0) {
		this->writeScore();
		this->context_->TransitionTo(new LoseState(engine_, context_));
	}

}

void BattleState::addScore(int amt) {
	score += amt;
}

void BattleState::levelUp() {
	requiredFrames = 175 / (0.8 * ++level); //dynamically make the game harder
	troopersKilledToLevelUp += 5;
	troopersKilled = 0;

	if (level == 5) {
		this->writeScore();
		this->context_->TransitionTo(new WinState(engine_, context_));
	}
}

void BattleState::damagePlayer() {
	Psydh9Character* luke = (Psydh9Character*)this->engine_->getContentItem(1); //luke
	luke->damage();
	
	if (luke->getHP() == 0) {
		this->writeScore();
		this->context_->TransitionTo(new LoseState(engine_, context_));
	}
};

void BattleState::writeScore() {
	std::ofstream myfile;
	myfile.open("scores.txt", std::ios_base::app); //opens the file in append mode
	myfile << this->score;
	myfile << "}\n";
	myfile.close();

	std::ifstream myfile2;
	myfile2.open("scores.txt", std::ios_base::in); //opens the file in append mode

	std::vector<std::string> strArr;
	std::vector<int> numbArr;
	std::string line;

	while (std::getline(myfile2, line)) {
		strArr.push_back(line);
		// Find the position of the first comma and the closing brace
		size_t comma_pos = line.find(',');
		size_t brace_pos = line.find('}');

		// Extract the substring between the comma and the brace
		std::string line2num = line.substr(comma_pos + 1, brace_pos - comma_pos - 1);

		line2num.erase(std::remove_if(line2num.begin(), line2num.end(), [](char c) {
			return !isdigit(c);
			}), line2num.end());
		// Convert the extracted string to an integer and print it to the console
		int num = std::stoi(line2num);
		numbArr.push_back(num);
	}

	myfile2.close();

	
	int n = strArr.size();

	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n - i - 1; j++) {
			if (numbArr[j] < numbArr[j + 1]) {
				std::string temp = strArr[j];
				strArr[j] = strArr[j + 1];
				strArr[j + 1] = temp;

				int temp2 = numbArr[j];
				numbArr[j] = numbArr[j + 1];
				numbArr[j + 1] = temp2;
			}
		}
	}

	std::ofstream myfile3;
	myfile3.open("scores.txt", std::ios_base::out); //opens the file in output mode7

	for (int i = 0; i < n; i++) {
		myfile3 << strArr[i];
		myfile3 << "\n";
	}
	myfile3.close();
}

DisplayableObject* BattleState::getDisplayableObject(int index) { return this->engine_->getDisplayableObject(index); }

int BattleState::getCharacterX(Psydh9Character* object) { return object->getX(); }
int BattleState::getCharacterY(Psydh9Character* object) { return object->getX(); }

bool BattleState::checkCollision(DisplayableObject* checkingObj) {
	int i = this->engine_->getContentCount();
	DisplayableObject* checkedObj = this->engine_->getContentItem(1); //luke
	if (CollisionDetection::checkRectangles(checkingObj->getDrawingRegionLeft(), checkingObj->getDrawingRegionRight(), checkingObj->getDrawingRegionTop(), checkingObj->getDrawingRegionBottom(),
		checkedObj->getDrawingRegionLeft(), checkedObj->getDrawingRegionRight(), checkedObj->getDrawingRegionTop(), checkedObj->getDrawingRegionBottom())) {
		
		return true;
	}
	return false;
}

Psydh9Context::Psydh9Context(Psydh9Engine* engine) {
	this->state_ = new MainMenuState(engine, this);
}