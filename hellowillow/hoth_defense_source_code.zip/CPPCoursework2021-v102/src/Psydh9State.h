#pragma once
#include "header.h"
#include "Psydh9Engine.h"
#include "Psydh9Trophy.h"
#include "Psydh9Character.h"
#include "Psydh9TileManager.h"
#include "Psydh9FilterPoints.h"
#include "ImageManager.h"
#include "UtilCollisionDetection.h"
#include <string>
#include <ctime>
#include <cmath>
#include <fstream>

class Psydh9Context;
class Psydh9Character;
class Psydh9Engine;


class Psydh9State
{

public:

	Psydh9State();

	Psydh9State(Psydh9Engine* engine, Psydh9Context* context);

	~Psydh9State();

	virtual void drawBackground() {};
	virtual void drawBackgroundString() {};
	virtual void drawForeground() {};
	virtual int initialiseObjects();
	virtual void setupBackgroundBuffer() {};
	virtual void keyDown(int keyCode) {};
	virtual void mouseDown(int button, int x, int y) {};
	virtual void doUpdate() {};
	virtual void addObject(DisplayableObject* object);
	virtual void removeObject(DisplayableObject* object);
	virtual void hit() {};
	virtual void damagePlayer() {};
	Psydh9Engine* getEngine();
	virtual bool checkCollision(DisplayableObject* checkingObj) { return false; };
	virtual void addScore(int amt) { score += amt; };
	virtual void mouseWheel(int x, int y, int which, int timestamp) {};
	virtual int getCharacterX(Psydh9Character* object) { return 0; }
	virtual int getCharacterY(Psydh9Character* object) { return 0; }
	virtual DisplayableObject* getDisplayableObject(int index) { return NULL; }


protected:
	int score = 0;
	Psydh9Engine* engine_ = nullptr;
	Psydh9Context* context_ = nullptr;
	Psydh9TileManager* tileManager = nullptr;
};

class MainMenuState :
	public Psydh9State
{
public:

	MainMenuState(Psydh9Engine* engine, Psydh9Context* context);

	~MainMenuState();

	void setupBackgroundBuffer() override;
	void keyDown(int keyCode) override;
	void mouseDown(int button, int x, int y) override;
	void mouseWheel(int x, int y, int which, int timestamp) override;

protected:
	Psydh9FilterPointsScaling* m_filterScaling;
	Psydh9FilterPointsTranslation* m_filterTranslation;
};

class NameEnterState :
	public Psydh9State
{
public:

	NameEnterState(Psydh9Engine* engine, Psydh9Context* context);

	~NameEnterState();

	void keyDown(int keyCode) override;
	void drawBackground() override;

	void drawBackgroundString() override;

	void doUpdate() override;

protected:
	int charsentered = 0;
	char buffer[4] = { '_', '_', '_', '\0'};
};

class WinState :
	public Psydh9State
{
	//show a victory graphic, if the next character (if there is one) is locked then unlock them
public:
	WinState(Psydh9Engine* engine, Psydh9Context* context);

	void drawBackground() override;
	void keyDown(int keyCode) override;
	void doUpdate() override;
	int frame = 0;
	DrawingSurface* surfaces[5] = { nullptr, nullptr, nullptr, nullptr, nullptr};
	SimpleImage winImage;
	SimpleImage winBack1;
	SimpleImage winBack2;
	SimpleImage winBack3;
	SimpleImage winBack4;
	SimpleImage winBack5;
};

class LoseState :
	public Psydh9State
{
	//show a loss graphic, if the next character (if there is one) is locked then unlock them
public:
	LoseState(Psydh9Engine* engine, Psydh9Context* context);

	~LoseState();

	void drawBackground() override;
	void keyDown(int keyCode) override;
	void doUpdate() override;
	int frame = 0;
	DrawingSurface* surfaces[5] = { nullptr, nullptr, nullptr, nullptr, nullptr };
	SimpleImage loseImage;
	SimpleImage loseBack1;
	SimpleImage loseBack2;
	SimpleImage loseBack3;
	SimpleImage loseBack4;
	SimpleImage loseBack5;
};

class ScoreState :
	public Psydh9State
{

	//read high scores from the files and output them as text to the screen
public:
	ScoreState(Psydh9Engine* engine, Psydh9Context* context);

	~ScoreState();

	void drawBackground() override;
	void keyDown(int keyCode) override;
};

class BattleState :
	public Psydh9State
{
public:
	int startTime;
	int shift = 0;

	BattleState(Psydh9Engine* engine, Psydh9Context* context);

	~BattleState();

	void drawBackground() override;
	void keyDown(int keyCode) override;

	void addStormTrooper();

	void setupBackgroundBuffer() override ;

	void drawForeground() {
		troopersKilled++;
		if (troopersKilled == troopersKilledToLevelUp) {
			this->levelUp();
		}
	}; //incredibly goofy function overload

	void damagePlayer() override;

	void removeObject(DisplayableObject* object) override;

	void levelUp();

	void hit() override;

	void addScore(int amt) override;

	void writeScore();

	int initialiseObjects() override;

	bool checkCollision(DisplayableObject* checkingObj) override;

	int getCharacterX(Psydh9Character* object);
	int getCharacterY(Psydh9Character* object);

	virtual DisplayableObject* getDisplayableObject(int index);

	void doUpdate() override;

protected: 
	SimpleImage hoth;
	SimpleImage hothfloor;
	int framesSinceSpawn = 75;
	int requiredFrames = 150;
	int level = 1;
	int hitPoints = 10;
	int troopersKilled = 0;
	int troopersKilledToLevelUp = 10;
	Psydh9TileManager* tileManager_ = nullptr;
	Psydh9ImagePixelMapping* imageMapper = nullptr;
};

class Psydh9Context
{
public:

	Psydh9Context(Psydh9Engine* engine);

	~Psydh9Context() {
		delete this->state_;
	}

	void TransitionTo(Psydh9State* newState) {
		if (this->state_ != nullptr)
			delete this->state_;
		this->state_ = newState;
		if(this->state_ != nullptr)
			this->state_->initialiseObjects();
			this->state_->drawBackground();
			this->state_->drawForeground();
	};
	
	void setupBackgroundBuffer() {
		this->state_->setupBackgroundBuffer();
	}

	void drawBackgroundString() {
		this->state_->drawBackgroundString();
	}

	virtual void drawForeground() {
		this->state_->drawForeground();
	};


	virtual void mouseDown(int button, int x, int y) {
		this->state_->mouseDown(button, x, y);
	};

	virtual int initialiseObjects() {
		this->state_->initialiseObjects();
		return 0;
	}

	virtual void keyDown(int keyCode) {
		this->state_->keyDown(keyCode);
	};

	virtual void doUpdate() {
		this->state_->doUpdate();
	}

	virtual void mouseWheel(int x, int y, int which, int timestamp) {
		this->state_->mouseWheel(x, y, which, timestamp);
	}

protected:
	Psydh9State* state_ = nullptr;
};
