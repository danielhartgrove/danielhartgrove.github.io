#pragma once
#include "header.h"
#include "TileManager.h"

class Psydh9TileManager :
	public TileManager
{
public:
    Psydh9TileManager(int tileWidth, int tileHeight, int tilesX, int tilesY) : TileManager(tileWidth, tileHeight, tilesX, tilesY) {};
    ~Psydh9TileManager() {};

	void virtDrawTileAt(
		BaseEngine* pEngine,
		DrawingSurface* pSurface,
		int iMapX, int iMapY,
		int iStartPositionScreenX, int iStartPositionScreenY) const
	{

		SimpleImage image = ImageManager::loadImage("heart.png", true); //loads up my grass image
		image.renderImageWithMask(pSurface,
			iStartPositionScreenX, // Left
			iStartPositionScreenY, // Top
			iStartPositionScreenX + 20, // Right
			iStartPositionScreenY + 20, // Bottom
			image.getWidth(), image.getHeight(), 0xff00ff
		);
	};
};