#pragma once
#include "header.h"
#include "BaseEngine.h"
#include "DisplayableObject.h"
#include "ImageManager.h"

class Psydh9Trophy :
    public DisplayableObject
{
public:
	SimpleImage sprite;

	Psydh9Trophy(int xStart, int yStart, BaseEngine* engine, int iWidth, int iHeight, bool useTopLeftFor00) : DisplayableObject(xStart, yStart, engine, iWidth, iHeight, useTopLeftFor00) {
		sprite = ImageManager::loadImage("luke_sprites.png", true);
	};
	
	void takeDamage() {};

	void virtDraw() {
		sprite.renderImage(getEngine()->getForegroundSurface(), 0, 0, 500, 375, 100, 100);
	};

	void virtDoUpdate(int iCurrentTime) {
		virtDraw();
	}

protected:
	float hitPoints;
	int x;
	int y;
};

class ShieldGenerator : public Psydh9Trophy {
public:
	SimpleImage sprite;

	ShieldGenerator(int xStart, int yStart, BaseEngine* engine, int iWidth, int iHeight, bool useTopLeftFor00) : Psydh9Trophy(xStart, yStart, engine, iWidth, iHeight, useTopLeftFor00) {
		sprite = ImageManager::loadImage("shield_generator.png", true);
	};

	void takeDamage() {
		hitPoints--;
		if (hitPoints == 0) {
			//play explosion animation, trigger end of the game somehow
		};
	};

	void virtDraw() {
		getEngine()->lockForegroundForDrawing();
		sprite.renderImageWithMaskAndTransparency(getEngine()->getForegroundSurface(), 180, 0, 0, 610, 58, 192, 0xff00ff, 100);
		getEngine()->unlockForegroundForDrawing();
	};

	void virtDoUpdate(int iCurrentTime) {
		virtDraw();
	}

protected:
	float hitPoints;
	int x = 58;
	int y = 800 - 192;
};

